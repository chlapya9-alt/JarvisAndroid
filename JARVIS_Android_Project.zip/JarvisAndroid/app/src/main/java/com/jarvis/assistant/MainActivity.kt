package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var resultCallback: ((String) -> Unit)? = null
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) listenNow() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onResults(b: Bundle?) { b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { resultCallback?.invoke(it) } }
                override fun onError(error: Int) { resultCallback?.invoke("Не удалось распознать речь. Попробуй ещё раз.") }
                override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}; override fun onPartialResults(b: Bundle?) {}; override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        setContent { JarvisUi(
            listen = { cb -> resultCallback = cb; if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) listenNow() else permission.launch(Manifest.permission.RECORD_AUDIO) },
            speak = { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "jarvis") },
            command = { handleCommand(it) }, ai = { key, prompt -> askAi(key, prompt) }
        ) }
    }
    private fun listenNow() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU") }
        recognizer?.startListening(i)
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ru", "RU") }
    private fun handleCommand(text: String): String? {
        val q = text.lowercase(Locale("ru", "RU"))
        fun open(pkg: String, label: String): String { val i = packageManager.getLaunchIntentForPackage(pkg); if (i != null) { startActivity(i); return "Открываю $label." }; return "$label не найден." }
        return when {
            "открой youtube" in q || "открой ютуб" in q -> open("com.google.android.youtube", "YouTube")
            "открой telegram" in q || "открой телеграм" in q -> open("org.telegram.messenger", "Telegram")
            "открой whatsapp" in q || "открой ватсап" in q -> open("com.whatsapp", "WhatsApp")
            "открой настройки" in q -> { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); "Открываю настройки." }
            "найди " in q || "поищи " in q -> { val term = text.substringAfter("найди ", text.substringAfter("поищи ", text)); startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(term)))); "Ищу в интернете: $term" }
            "будильник" in q -> { val m = Regex("(\\d{1,2})[:.](\\d{2})").find(q); if (m == null) "Назови время, например 7:30." else { startActivity(Intent(android.provider.AlarmClock.ACTION_SET_ALARM).putExtra(android.provider.AlarmClock.EXTRA_HOUR, m.groupValues[1].toInt()).putExtra(android.provider.AlarmClock.EXTRA_MINUTES, m.groupValues[2].toInt()).putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "JARVIS")); "Открываю создание будильника." } }
            "напомни" in q || "напоминание" in q -> { startActivity(Intent(Intent.ACTION_INSERT).setData(Uri.parse("content://com.android.calendar/events")).putExtra("title", text)); "Открываю календарь для создания напоминания." }
            else -> null
        }
    }
    private suspend fun askAi(key: String, prompt: String): String = withContext(Dispatchers.IO) {
        try {
            val c = URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 30000; c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer $key"); c.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().put("model", "gpt-4o-mini").put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", "Ты JARVIS, голосовой помощник. Отвечай кратко на русском.")).put(JSONObject().put("role", "user").put("content", prompt)))
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (c.responseCode !in 200..299) "Ошибка API ${c.responseCode}: $response" else JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        } catch (e: Exception) { "Ошибка соединения с ИИ: ${e.localizedMessage}" }
    }
    override fun onDestroy() { recognizer?.destroy(); tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun JarvisUi(listen: ((String) -> Unit) -> Unit, speak: (String) -> Unit, command: (String) -> String?, ai: suspend (String, String) -> String) {
    var key by remember { mutableStateOf("") }; var settings by remember { mutableStateOf(false) }; var input by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }
    val log = remember { mutableStateListOf("JARVIS: Система готова. Чем могу помочь?") }; val scope = rememberCoroutineScope()
    val background = Brush.verticalGradient(listOf(Color(0xFF020914), Color(0xFF09263B), Color(0xFF020914)))
    fun submit(s: String) {
        if (s.isBlank()) return
        log.add("ВЫ: $s"); input = ""
        val local = command(s)
        if (local != null) { log.add("JARVIS: $local"); speak(local); return }
        if (key.isBlank()) { val msg = "Для общения с ИИ добавь API-ключ в настройках. Голосовые команды телефона доступны без него."; log.add("JARVIS: $msg"); speak(msg); return }
        busy = true; scope.launch { val answer = ai(key.trim(), s); log.add("JARVIS: $answer"); speak(answer); busy = false }
    }
    Column(Modifier.fillMaxSize().background(background).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("J.A.R.V.I.S.", color = Color(0xFF61DFFF), fontSize = 30.sp); Text("PERSONAL AI ASSISTANT", color = Color(0xFF8AB8CC), fontSize = 10.sp) }; TextButton(onClick = { settings = !settings }) { Text("⚙", color = Color.Cyan, fontSize = 24.sp) } }
        Card(Modifier.fillMaxWidth().padding(top = 12.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF08243A)), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(142.dp).background(Brush.radialGradient(listOf(Color(0xFF197BA4), Color(0xFF071A2B), Color.Transparent)), CircleShape), contentAlignment = Alignment.Center) { Text("◉", color = Color(0xFF73E8FF), fontSize = 78.sp) }
                Text(if (busy) "ОБРАБОТКА ЗАПРОСА" else "СИСТЕМА ГОТОВА", color = Color(0xFF65DFFF), fontSize = 12.sp)
                Button(onClick = { listen { submit(it) } }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087EA4))) { Text("🎙  ГОВОРИТЬ С ДЖАРВИСОМ") }
            }
        }
        if (settings) { OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("OpenAI API key") }, singleLine = true); Text("Ключ хранится в памяти только до закрытия приложения.", color = Color.LightGray, fontSize = 11.sp) }
        Text("ЖУРНАЛ СИСТЕМЫ", color = Color(0xFF61DFFF), modifier = Modifier.padding(top = 14.dp), fontSize = 12.sp)
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) { items(log) { Text(it, color = Color(0xFFD9F5FF), modifier = Modifier.padding(vertical = 5.dp), fontSize = 13.sp) } }
        Row(verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Введите команду...") }, singleLine = true); Spacer(Modifier.width(8.dp)); Button(onClick = { submit(input) }, enabled = !busy) { Text("OK") } }
    }
}
